package com.zenixo.spring.repo;

import com.zenixo.spring.entity.BookingDetails;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookingDetailsRepo extends JpaRepository<BookingDetails, String> {
}
