package com.zenixo.spring.entity;


public class Returns {
    private String returnID;
    private String rentData;
    private String returnData;
    private String rentID;
    private String looseDamage;


}
