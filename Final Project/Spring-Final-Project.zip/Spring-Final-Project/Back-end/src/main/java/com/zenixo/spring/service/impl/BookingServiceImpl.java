package com.zenixo.spring.service.impl;

import com.zenixo.spring.dto.BookingDTO;
import com.zenixo.spring.dto.BookingDetailsDTO;
import com.zenixo.spring.entity.Booking;
import com.zenixo.spring.entity.BookingDetails;
import com.zenixo.spring.entity.Drivers;
import com.zenixo.spring.repo.BookingDetailsRepo;
import com.zenixo.spring.repo.BookingRepo;
import com.zenixo.spring.repo.DriverRepo;
import com.zenixo.spring.service.BookingService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
@Transactional
public class BookingServiceImpl implements BookingService {
    @Autowired
    ModelMapper mapper;
    @Autowired
    BookingRepo bookingRepo;
    @Autowired
    BookingDetailsRepo bookingDetailsRepo;
    @Autowired
    DriverRepo driverRepo;

    @Override
    public void addBooking(BookingDTO dto) {
        Booking booking = new Booking(
                dto.getBookingID(),
                dto.getRentDate(),
                dto.getReturnDate(),
                "Not Approved",
                "On Rent",
                dto.getCustNICNumber(),
                dto.getDriverNICNumber()
        );

        Booking bookingSaved = bookingRepo.save(booking);

        if (bookingSaved != null) {
            for (BookingDetailsDTO bok : dto.getBookingDetails()) {
                BookingDetails bookingDetails = new BookingDetails(
                        bok.getLossDamage(),
                        bok.getLossDamageImage(),
                        bok.getBookingID(),
                        bok.getVehicleRegID()
                );
                bookingDetailsRepo.save(bookingDetails);
            }
        }
//        Drivers drivers=new Drivers(
//                dto.getDriverNICNumber()+""
//        );

//         driverRepo.save(mapper.map(Drivers drivers = new Drivers(dto.getDriverNICNumber() + "")));
//        driverRepo.updateStatusForDriver(drivers);

//        if (driverRepo.existsById(dto.getDriverNICNumber()+"")){
//
//        }

    }
}
