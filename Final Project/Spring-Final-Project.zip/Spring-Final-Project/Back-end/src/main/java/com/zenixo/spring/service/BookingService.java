package com.zenixo.spring.service;

import com.zenixo.spring.dto.BookingDTO;

public interface BookingService {
    void addBooking(BookingDTO bookingDTO);
}
