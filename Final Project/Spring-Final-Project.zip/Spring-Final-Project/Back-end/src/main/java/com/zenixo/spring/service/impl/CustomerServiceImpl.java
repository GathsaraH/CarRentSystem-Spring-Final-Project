package com.zenixo.spring.service.impl;

import com.zenixo.spring.dto.CustomerDTO;
import com.zenixo.spring.entity.Customer;
import com.zenixo.spring.exception.ValidateException;
import com.zenixo.spring.repo.CustomerRepo;
import com.zenixo.spring.service.CustomerService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Optional;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {
    @Autowired
    private ModelMapper mapper;
    @Autowired
    private CustomerRepo customerRepo;

    @Override
    public void saveCustomer(CustomerDTO dto) {
        if (customerRepo.existsById(dto.getCustNICNumber())) {
            throw new ValidateException("Customer Already Exist");
        }
        customerRepo.save(mapper.map(dto, Customer.class));
    }

    @Override
    public CustomerDTO searchCustomer(String custNICNumber) {
        Optional<Customer> customer = customerRepo.findById(custNICNumber);
        if (customer.isPresent()) {
            return mapper.map(customer.get(), CustomerDTO.class);
        }
        return null;
    }
}
