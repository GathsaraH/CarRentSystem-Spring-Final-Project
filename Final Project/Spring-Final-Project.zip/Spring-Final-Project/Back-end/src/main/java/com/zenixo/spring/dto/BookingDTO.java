package com.zenixo.spring.dto;

import com.zenixo.spring.entity.BookingDetails;
import com.zenixo.spring.entity.Customer;
import com.zenixo.spring.entity.Drivers;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class BookingDTO {
    private String bookingID;
    private java.sql.Date  rentDate;
    private java.sql.Date  returnDate;
    private double lossDamage;
    private String lossDamageImage;
    private String bookingStatus;
    private Customer custNICNumber;
    private Drivers driverNICNumber;
    private String rentStatus;
    private List<BookingDetailsDTO>bookingDetails=new ArrayList<>();

    public BookingDTO(String bookingID, java.sql.Date  rentDate, java.sql.Date  returnDate, double lossDamage, String lossDamageImage, String bookingStatus, Customer custNICNumber, Drivers driverNICNumber) {
        this.bookingID = bookingID;
        this.rentDate = rentDate;
        this.returnDate = returnDate;
        this.lossDamage = lossDamage;
        this.lossDamageImage = lossDamageImage;
        this.bookingStatus = bookingStatus;
        this.custNICNumber = custNICNumber;
        this.driverNICNumber = driverNICNumber;
    }

}
