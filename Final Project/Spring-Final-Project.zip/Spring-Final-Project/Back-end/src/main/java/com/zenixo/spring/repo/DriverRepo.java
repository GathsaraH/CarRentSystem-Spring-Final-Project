package com.zenixo.spring.repo;

import com.zenixo.spring.entity.Drivers;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface DriverRepo extends JpaRepository<Drivers, String> {

//    @Query(value = "", nativeQuery = true)
//    void updateStatusForDriver(Drivers driverNICNumber);
}
