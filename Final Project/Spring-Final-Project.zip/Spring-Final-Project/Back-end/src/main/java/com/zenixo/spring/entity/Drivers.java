package com.zenixo.spring.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import java.util.ArrayList;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Drivers {
    @Id
    private String driverNICNumber;
    private String driverName;
    private String driverNICImage;
    private String driverDrivingLyImage;
    private String driverDrivingLyNumber;
    private String driverContact;
    private String driverEmail;
    private String driverPassword;
    private String driverStatus;
    @OneToMany(mappedBy = "driverNICNumber", cascade = {CascadeType.ALL})
    private List<Booking> bookings;

    public Drivers(String driverNICNumber, String driverName, String driverNICImage, String driverDrivingLyImage, String driverDrivingLyNumber, String driverContact, String driverEmail, String driverPassword, String driverStatus) {
        this.driverNICNumber = driverNICNumber;
        this.driverName = driverName;
        this.driverNICImage = driverNICImage;
        this.driverDrivingLyImage = driverDrivingLyImage;
        this.driverDrivingLyNumber = driverDrivingLyNumber;
        this.driverContact = driverContact;
        this.driverEmail = driverEmail;
        this.driverPassword = driverPassword;
        this.driverStatus = driverStatus;
    }

    public Drivers(String driverNICNumber) {
        this.driverNICNumber = driverNICNumber;
    }



//    @OneToMany(mappedBy = "driverNICNumber", cascade = {CascadeType.ALL})
//    private List<BookingDetails> bookingDetails=new ArrayList<>();


//        "driverNICNumber":"1254848",
//     "driverName":"Ruwan",
//     "driverNICImage":"NIC Image",
//     "driverDrivingLyImage":"Driver Image",
//     "driverDrivingLyNumber":"2558652659",
//     "driverContact":"07165822821",
//     "driverEmail":"Driver@gmail.com",
//     "driverPassword":"12345"
//    }
}
