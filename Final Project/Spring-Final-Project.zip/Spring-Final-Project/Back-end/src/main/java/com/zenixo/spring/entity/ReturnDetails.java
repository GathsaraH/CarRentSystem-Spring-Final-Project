package com.zenixo.spring.entity;

public class ReturnDetails {
}
