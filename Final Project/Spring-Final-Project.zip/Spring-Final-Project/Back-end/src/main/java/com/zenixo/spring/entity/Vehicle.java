package com.zenixo.spring.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import java.util.ArrayList;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Vehicle {
    @Id
    private String vehicleRegID;
    private String vehicleMainBrand;
    private String vehicleSubBrand;
    private String vehicleType;
//    private String vehicleNumberOfPassage;
//    private String vehicleTransmissionType;
//    private String vehicleFuelType;
//    private String vehicleColor;

    private double vehicleDailyRate;
    private double vehicleMonthlyRate;
    private String vehicleFreeMiles;
    private String vehicleExtraKmPrice;

//    @OneToMany(mappedBy = "vehicleRegID", cascade = {CascadeType.ALL})
//    private List<Booking> bookings;

//    @OneToMany(mappedBy = "vRegID", cascade = {CascadeType.ALL})
//    private List<BookingDetails> bookingDetails=new ArrayList<>();


//    {
//        "vRegID":"HH-7527",
//            "vMainBrand":"Audi",
//            "vSubBrand":"A1",
//            "Type":: "Luxry",
//            "vNumberOfPassage":"6",
//            "vTransmissionType":"Auto",
//            "vFuelType":"Desel",
//            "vColor":"Black",
//            "vDailyRate":"400",
//            "vMonthlyRate":"500",
//            "vFreeMiles":"2",
//            "vExtraKmPrice":"8000"
//
//    }
}
