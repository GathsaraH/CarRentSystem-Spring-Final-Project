package com.zenixo.spring.dto;

import com.zenixo.spring.entity.Booking;
import com.zenixo.spring.entity.Vehicle;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class BookingDetailsDTO {
    private int bookingDetailsID;
    private double lossDamage;
    private String lossDamageImage;
    private Booking bookingID;
    private Vehicle vehicleRegID;
}
