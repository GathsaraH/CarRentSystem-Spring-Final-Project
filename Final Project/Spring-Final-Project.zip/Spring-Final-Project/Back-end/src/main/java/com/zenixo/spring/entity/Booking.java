package com.zenixo.spring.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Booking {
    @Id
    private String bookingID;
    private java.sql.Date rentDate;
    private java.sql.Date returnDate;
    private String bookingStatus; //For Admin Approvel
    private String rentStatus;
    @ManyToOne
    @JoinColumn(name = "custNICNumber", referencedColumnName = "custNICNumber")
    private Customer custNICNumber;


    /*@ManyToOne
    @JoinColumn(name = "vehicleRegID", referencedColumnName = "vehicleRegID")
    private Vehicle vehicleRegID;*/


    @ManyToOne
    @JoinColumn(name = "driverNICNumber", referencedColumnName = "driverNICNumber")
    private Drivers driverNICNumber; //If Not required Then Send Not Assign else Send Drive Id


    @OneToMany(mappedBy = "bookingID")
    private List<BookingDetails> bookingDetails = new ArrayList<>();


//    @OneToMany(mappedBy = "bkID", cascade = {CascadeType.ALL})
//    private List<BookingDetails> bookingDetails;


    public Booking(String bookingID, java.sql.Date  rentDate, java.sql.Date  returnDate, String bookingStatus, String rentStatus, Customer custNICNumber, Drivers driverNICNumber) {
        this.bookingID = bookingID;
        this.rentDate = rentDate;
        this.returnDate = returnDate;
        this.bookingStatus = bookingStatus;
        this.rentStatus = rentStatus;
        this.custNICNumber = custNICNumber;
        this.driverNICNumber = driverNICNumber;
    }


}
