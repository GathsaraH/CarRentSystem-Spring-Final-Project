package com.zenixo.spring.service;

import com.zenixo.spring.dto.DriverDTO;

public interface DriverService {
    void addDrivers(DriverDTO dto);
}
