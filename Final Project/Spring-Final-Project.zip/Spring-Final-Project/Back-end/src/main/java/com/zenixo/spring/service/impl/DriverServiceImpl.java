package com.zenixo.spring.service.impl;

import com.zenixo.spring.dto.DriverDTO;
import com.zenixo.spring.entity.Drivers;
import com.zenixo.spring.exception.ValidateException;
import com.zenixo.spring.repo.DriverRepo;
import com.zenixo.spring.service.DriverService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
@Transactional
public class DriverServiceImpl implements DriverService {
    @Autowired
    private ModelMapper mapper;
    @Autowired
    private DriverRepo driverRepo;
    @Override
    public void addDrivers(DriverDTO dto) {
        Drivers drivers=new Drivers(
                dto.getDriverNICNumber(),
                dto.getDriverName(),
                dto.getDriverNICImage(),
                dto.getDriverDrivingLyImage(),
                dto.getDriverDrivingLyNumber(),
                dto.getDriverContact(),
                dto.getDriverEmail(),
                dto.getDriverPassword(),
                "NOT ASSIGN"
        );
        driverRepo.save(drivers);
    }
//        if (driverRepo.existsById(dto.getDriverNICNumber())) {
//            throw new ValidateException("Customer Already Exist");
//        }
//        driverRepo.save(mapper.map(dto, Drivers.class));
//    }
}
