package com.zenixo.spring.service;

import com.zenixo.spring.dto.CustomerDTO;

public interface CustomerService {
    void saveCustomer(CustomerDTO dto);
    CustomerDTO searchCustomer(String custNICNumber);
}
