package com.zenixo.spring.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class VehicleDTO {
    private String vehicleRegID;
    private String vehicleMainBrand;
    private String vehicleSubBrand;
    private String vehicleType;
    private String vehicleNumberOfPassage;
    private String vehicleTransmissionType;
    private String vehicleFuelType;
    private String vehicleColor;
    private double vehicleDailyRate;
    private double vehicleMonthlyRate;
    private String vehicleFreeMiles;
    private String vehicleExtraKmPrice;
}
