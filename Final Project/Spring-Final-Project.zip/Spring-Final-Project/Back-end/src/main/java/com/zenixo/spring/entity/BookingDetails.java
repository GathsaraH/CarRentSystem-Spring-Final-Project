package com.zenixo.spring.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;


@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class BookingDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int bookingDetailsID;
    private double lossDamage;
    private String lossDamageImage;


    @ManyToOne
    @JoinColumn(name = "bookingID", referencedColumnName = "bookingID")
    private Booking bookingID;

    @ManyToOne
    @JoinColumn(name = "vehicleRegID", referencedColumnName = "vehicleRegID")
    private Vehicle vehicleRegID;

    public BookingDetails(double lossDamage, String lossDamageImage, Booking bookingID, Vehicle vehicleRegID) {
        this.lossDamage = lossDamage;
        this.lossDamageImage = lossDamageImage;
        this.bookingID = bookingID;
        this.vehicleRegID = vehicleRegID;
    }
}
